Usage: mpirun.openmpi -np 13 ./mpi

if your input number is correct, the flag will be printed for you.