flag is in /etc/flag
