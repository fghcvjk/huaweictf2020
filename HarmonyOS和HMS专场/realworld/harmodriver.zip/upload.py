import sys
import os


path = "/PWN/nfs"

def upload_file():
    print("Please input your exploit in hex format. You can enter in mutilple lines. Append an line of 'Exit' to finish") 
    content = ""
    while True:
        line = raw_input()
        if 'Exit' == line.strip():
            break
        content += line.strip()

    content = content.decode('hex')
    
    with open(path + "/pwn", 'w') as f:
        f.write(content)

try:
    if os.path.exists(path+"/pwn"):
        os.remove(path + "/pwn")
    upload_file()
except:
    print("File upload error")
    exit()

print("Please wait for one minute for the server to run")

## start service
## We will execute your file in the harmony system
## but we omit the details here
print("Executing")
print("Fetching result")
print("Hope you get the flag")
