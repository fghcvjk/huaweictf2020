I wrote a driver called `HdfSampleDriver`. I am so excited.
